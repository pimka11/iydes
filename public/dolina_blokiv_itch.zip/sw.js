/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-6610412a'], (function (workbox) { 'use strict';

  workbox.setCacheNameDetails({
    prefix: "dolina-blokiv-v11"
  });
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "f580959b8cbba6b1d91fafbebe0145cb"
  }, {
    "url": "pwa-512x512.png",
    "revision": "c0d5c1f382944e23c6bd1d809a47f87b"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3135221e4a196bcaf4d77a826de9e6e2"
  }, {
    "url": "icon.svg",
    "revision": "ae5ed499fb0f8b9cd4a520b1358162d5"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "1557d5697697419d67a745312a6a29eb"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-DjiiOYjA.js",
    "revision": null
  }, {
    "url": "assets/index-CT3Lngg9.css",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ef20f35f.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_9717d830.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_94e7ede2.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_5f298201.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_1e4ba9f0.png",
    "revision": null
  }, {
    "url": "assets/aistudio/2026-09-29_121604_edbd73f6.png",
    "revision": null
  }, {
    "url": "assets/aistudio/2026-09-29_114618_08f4377c.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "1557d5697697419d67a745312a6a29eb"
  }, {
    "url": "icon.svg",
    "revision": "ae5ed499fb0f8b9cd4a520b1358162d5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3135221e4a196bcaf4d77a826de9e6e2"
  }, {
    "url": "pwa-512x512.png",
    "revision": "c0d5c1f382944e23c6bd1d809a47f87b"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f580959b8cbba6b1d91fafbebe0145cb"
  }, {
    "url": "manifest.webmanifest",
    "revision": "cfaf1c6e0bad3bec00259e95f5c1d0df"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(({
    request
  }) => request.mode === "navigate", new workbox.NetworkFirst({
    "cacheName": "html-pages-v11",
    "networkTimeoutSeconds": 4,
    plugins: []
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
